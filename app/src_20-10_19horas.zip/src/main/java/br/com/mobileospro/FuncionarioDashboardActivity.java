package br.com.mobileospro;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FuncionarioDashboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funcionario_dashboard);

        Button manageClients = findViewById(R.id.btnManageClients);
        Button manageServiceOrders = findViewById(R.id.btnManageServiceOrders);
        Button manageVehicle = findViewById(R.id.btnManageVehicles);

        manageClients.setOnClickListener(v -> {
            Intent intent = new Intent(FuncionarioDashboardActivity.this, AddClient.class);
            startActivity(intent);
        });

        manageServiceOrders.setOnClickListener(v -> {
            Intent intent = new Intent(FuncionarioDashboardActivity.this, ServiceReportActivity.class);
            startActivity(intent);
        });

        manageVehicle.setOnClickListener(v -> {
            Intent intent = new Intent(FuncionarioDashboardActivity.this, AddVehiclesHistory.class);
            startActivity(intent);
        });
    }
}

