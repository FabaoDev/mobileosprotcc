package br.com.mobileospro;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddClient extends AppCompatActivity {

    private EditText etClientName, etClientAddress, etClientPhone;
    private Button btnAddClient;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_client);

        etClientName = findViewById(R.id.etClientName);
        etClientAddress = findViewById(R.id.etClientAddress);
        etClientPhone = findViewById(R.id.etClientPhone);
        btnAddClient = findViewById(R.id.btnAddClient);
        db = new DatabaseHelper(this);

        btnAddClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClient();
            }
        });
    }

    private void addClient() {
        String name = etClientName.getText().toString();
        String address = etClientAddress.getText().toString();
        String phone = etClientPhone.getText().toString();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(address) || TextUtils.isEmpty(phone)) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            long isInserted = db.addClient(name, address, phone);
            if (isInserted != -1) {
                Toast.makeText(this, "Cliente cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                finish(); // Fecha a activity após o cadastro
            } else {
                Toast.makeText(this, "Erro ao cadastrar cliente", Toast.LENGTH_SHORT).show();
            }
        }
    }
}