package br.com.mobileospro;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ManageClientsActivity extends AppCompatActivity {

    private EditText etClientName, etClientAddress, etClientPhone; // Declare aqui corretamente o campo de endereço e telefone
    private Button btnAddClient;
    private ListView lvClients;
    private DatabaseHelper db;
    private ArrayAdapter<String> clientAdapter;
    private ArrayList<String> clientList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_clients);

        etClientName = findViewById(R.id.etClientName);
        etClientAddress = findViewById(R.id.etClientAddress); // Inicialize o campo de endereço
        etClientPhone = findViewById(R.id.etClientPhone); // Inicialize o campo de telefone
        btnAddClient = findViewById(R.id.btnAddClient);
        lvClients = findViewById(R.id.lvClients);

        db = new DatabaseHelper(this);
        clientList = new ArrayList<>();
        clientAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, clientList);
        lvClients.setAdapter(clientAdapter);

        // Botão para adicionar cliente
        btnAddClient.setOnClickListener(v -> {
            String name = etClientName.getText().toString();
            String address = etClientAddress.getText().toString(); // Obtenha o valor do endereço
            String phone = etClientPhone.getText().toString();

            if (!name.isEmpty() && !address.isEmpty() && !phone.isEmpty()) { // Verifique se o endereço também está preenchido
                long result = db.addClient(name, address, phone); // Passe o endereço também
                if (result != -1) {
                    Toast.makeText(ManageClientsActivity.this, "Cliente adicionado com sucesso", Toast.LENGTH_SHORT).show();
                    etClientName.setText("");
                    etClientAddress.setText(""); // Limpe o campo de endereço
                    etClientPhone.setText("");
                    loadClients();
                } else {
                    Toast.makeText(ManageClientsActivity.this, "Erro ao adicionar cliente", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ManageClientsActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            }
        });

        // Carregar clientes na ListView
        loadClients();
    }

    private void loadClients() {
        clientList.clear();
        Cursor cursor = db.getAllClients();
        if (cursor.moveToFirst()) {
            do {
                String clientName = cursor.getString(cursor.getColumnIndex("client_name"));
                String clientPhone = cursor.getString(cursor.getColumnIndex("client_phone"));
                clientList.add(clientName + " - " + clientPhone);
            } while (cursor.moveToNext());
        }
        clientAdapter.notifyDataSetChanged();
    }
}