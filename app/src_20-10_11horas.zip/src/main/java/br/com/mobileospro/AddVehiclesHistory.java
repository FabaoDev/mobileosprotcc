package br.com.mobileospro;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddVehiclesHistory extends AppCompatActivity {

    private EditText etOwnerName, etModel, etPlate, etYear;
    private Button btnAddVehicle;
    private ListView lvVehicles;
    private DatabaseHelper db;
    private ArrayAdapter<String> vehicleAdapter;
    private ArrayList<String> vehicleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_vehicles);

        etOwnerName = findViewById(R.id.etOwnerName);
        etModel = findViewById(R.id.etVehicleModel);
        etPlate = findViewById(R.id.etVehiclePlate);
        etYear = findViewById(R.id.etVehicleYear);
        btnAddVehicle = findViewById(R.id.btnAddVehicle);
        lvVehicles = findViewById(R.id.lvVehicles);

        db = new DatabaseHelper(this);
        vehicleList = new ArrayList<>();
        vehicleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, vehicleList);
        lvVehicles.setAdapter(vehicleAdapter);

        // Botão para adicionar um veículo
        btnAddVehicle.setOnClickListener(v -> {
            String ownerName = etOwnerName.getText().toString();
            String model = etModel.getText().toString();
            String plate = etPlate.getText().toString();
            String year = etYear.getText().toString();

            if (!ownerName.isEmpty() && !model.isEmpty() && !plate.isEmpty() && !year.isEmpty()) {
                long result = db.addVehicle(ownerName, model, plate, year); // Chama o método addVehicle
                if (result != -1) {
                    Toast.makeText(AddVehiclesHistory.this, "Veículo adicionado com sucesso", Toast.LENGTH_SHORT).show();
                    etOwnerName.setText("");
                    etModel.setText("");
                    etPlate.setText("");
                    etYear.setText("");
                    loadVehicles(); // Atualiza a lista de veículos
                } else {
                    Toast.makeText(AddVehiclesHistory.this, "Erro ao adicionar veículo", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(AddVehiclesHistory.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            }
        });

        // Carregar veículos na ListView
        loadVehicles();
    }

    private void loadVehicles() {
        vehicleList.clear();
        Cursor cursor = db.getAllVehicles(); // Chama o método getAllVehicles
        if (cursor.moveToFirst()) {
            do {
                String ownerName = cursor.getString(cursor.getColumnIndex("owner_name"));
                String model = cursor.getString(cursor.getColumnIndex("model"));
                String plate = cursor.getString(cursor.getColumnIndex("plate"));
                String year = cursor.getString(cursor.getColumnIndex("year"));
                vehicleList.add(ownerName + " - " + model + " - " + plate + " - Ano: " + year);
            } while (cursor.moveToNext());
        }
        cursor.close();
        vehicleAdapter.notifyDataSetChanged();
    }
}
